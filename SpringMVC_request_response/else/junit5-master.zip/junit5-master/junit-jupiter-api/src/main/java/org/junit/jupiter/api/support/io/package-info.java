/**
 * IO-related support classes and built-in extensions.
 */

package org.junit.jupiter.api.support.io;
