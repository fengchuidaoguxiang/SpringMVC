/**
 * Extensions which provide support for conditional test execution features of
 * JUnit 4 (e.g., the {@link org.junit.Ignore @Ignore} annotation) within JUnit
 * Jupiter.
 */

package org.junit.jupiter.migrationsupport.conditions;
